console.log("hello world");
console.log("My name is Kumar /n");
console.log("My favorite cusine is Italian/n");
console.log("I am part of the spark");

alert("My name is Kumar");
alert("My favorite cusine is Italian");
alert("I am part of the spark");
